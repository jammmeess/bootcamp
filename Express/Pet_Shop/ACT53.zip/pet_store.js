const pets = [
  { id: 0, species: "Dog", breed: "Golden Retriever", name: "Miles" },
  { id: 1, species: "Cat", breed: "Tabby", name: "Piko" },
  { id: 2, species: "Cat", breed: "Persian", name: "Incu" },
  { id: 3, species: "Sugar-Glider", breed: "Standard Grey", name: "Porter" },
  { id: 4, species: "Dog", breed: "Shi-Tzu", name: "Milo" },
  { id: 5, species: "Cat", breed: "Tabby", name: "Mongmong" },
  { id: 6, species: "Cat", breed: "Persian", name: "Sasha" },
  { id: 7, species: "Dog", breed: "Terrier", name: "Marky" },
  { id: 8, species: "Dog", breed: "Daschund", name: "Digong" },
  { id: 9, species: "Rabbit", breed: "Mini Lop", name: "Flor" },
  { id: 10, species: "Racoon", breed: "Cozumel", name: "Rocket" },
  { id: 11, species: "Walrus", breed: "Walrus", name: "Teefs" },
  { id: 12, species: "Otter", breed: "Eurasian Otter", name: "Layla" },
  { id: 13, species: "Dog", breed: "Golden Retriever", name: "Cosmo" },
  { id: 14, species: "Dog", breed: "Golden Retriever", name: "Lucky" },
  { id: 15, species: "Duck", breed: "American Pekin", name: "Howard" },
];

module.exports = { pets };
