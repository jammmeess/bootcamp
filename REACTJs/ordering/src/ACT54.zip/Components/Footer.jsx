import React, { Component } from "react";
import "../css/styles.css";

class Footer extends Component {
  render() {
    return (
      <footer class="footer">
        <div class="container">
          <div class="row">
            <div
              class="col-lg-12 text-center
            "
            >
              <p>09123456789 | Kristoffer James Bomediano</p>
            </div>
          </div>
        </div>
      </footer>
    );
  }
}

export default Footer;
